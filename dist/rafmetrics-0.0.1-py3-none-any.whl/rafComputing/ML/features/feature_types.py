"""Contains all possible feature modification types"""

POLYNOMIAL_FEATURE_TYPE = "POLYNOMIAL"
POWER_FEATURE_TYPE = "POWER"
NO_FEATURE_TYPE = "NO_TYPE"
