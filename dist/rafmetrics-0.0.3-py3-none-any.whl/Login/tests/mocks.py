user1 = {
    "Created":
    "Thu, 07 Nov 2019 08:46:20 GMT",
    "Email":
    "test@email.com",
    "FirstName":
    "test_first_name",
    "LastName":
    "test_last_name",
    "Userid":
    1,
    "Username":
    "TestUsername",
    "hashedpassword":
    "pbkdf2:sha256:150000$3LCL1PDp$dd4ad95d664ce4b6fc0b7c9fe5870e793c3d364160c83fbd67fb1589fc5ab486",
}

user2 = {
    "Created":
    "Tue, 12 Nov 2019 12:52:59 GMT",
    "Email":
    "flask_test_email",
    "FirstName":
    "flask_test_first_name",
    "LastName":
    "flask_test_last_name",
    "Userid":
    2,
    "Username":
    "flask_test_username",
    "hashedpassword":
    "pbkdf2:sha256:150000$ZIYIaFBX$963996e4c5dbd588b4f24f7a08d4bf801fc0c495e22c779ae333a2901e3b1bd3",
}

users_dict = [user1, user2]
