class PERIOD:
    DAILY = "daily"
    WEEKLY = "weekly"
    MONTHLY = "monthly"


# Converting BYTES to KB, MB, GB
BYTES_TO_KBYTES = 1024
BYTES_TO_MBYTES = 1048576
BYTES_TO_GBYTES = 1073741824
