from itertools import cycle

plotting_points_symbols = ["o", "x"]
pool_plotting_points_symbols = cycle(plotting_points_symbols)
